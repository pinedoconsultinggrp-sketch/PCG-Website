import React from "react";
export default function Pricing() {
  const tiers = [
    { name: "Starter", price: "$299/mo", features: ["Monthly books", "Email support"]},
    { name: "Growth", price: "$499/mo", features: ["Bi-weekly updates", "Priority support"]},
    { name: "Construction Pro", price: "Custom", features: ["Job-costing", "Payroll add-ons"]},
  ];
  return (
    <section id="pricing" className="bg-white">
      <div className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="text-2xl md:text-3xl font-semibold">Pricing</h2>
        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {tiers.map((t) => (
            <div key={t.name} className="rounded-2xl border p-6">
              <div className="text-lg font-medium">{t.name}</div>
              <div className="text-3xl font-bold mt-2">{t.price}</div>
              <ul className="mt-4 space-y-1 text-gray-600 text-sm">
                {t.features.map(f => <li key={f}>• {f}</li>)}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
