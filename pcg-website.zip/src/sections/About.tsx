import React from "react";
export default function About() {
  return (
    <section id="about" className="bg-gray-50">
      <div className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="text-2xl md:text-3xl font-semibold">About</h2>
        <p className="mt-4 text-gray-700 max-w-3xl">
          We provide bilingual bookkeeping and advisory with a focus on construction and small businesses in Central Texas.
          Clear communication, accurate records, and on-time delivery—every month.
        </p>
      </div>
    </section>
  )
}
