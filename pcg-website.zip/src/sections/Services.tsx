import React from "react";
export default function Services() {
  return (
    <section id="services" className="bg-gray-50">
      <div className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="text-2xl md:text-3xl font-semibold">Services</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {["Bookkeeping","Payroll","Cleanup/Catch‑Up","Construction Job‑Costing","Taxes","Advisory"].map((s)=> (
            <div key={s} className="rounded-2xl border p-5 bg-white">
              <div className="font-medium">{s}</div>
              <p className="text-sm text-gray-600 mt-2">Short description of {s.toLowerCase()} offering.</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
