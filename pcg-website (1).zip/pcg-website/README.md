# Pinedo Consulting Group Website

This folder contains a lightweight, bilingual single‑page website for **Pinedo Consulting Group** (PCG).  The goal of this design is to seamlessly replace your existing Netlify deployment without requiring any complicated build tooling or frameworks.

## Overview

* Built with plain HTML, TailwindCSS (via the CDN) and a small amount of vanilla JavaScript.
* Supports English and Spanish languages via a simple toggle in the header.  All translatable strings are contained in a single JavaScript object (`translations`), making it easy to update or add more languages in the future.
* Sections include:
  - **Hero**:  concise positioning statement with call–to–action buttons.
  - **Who We Serve**:  lists industries and business types PCG specialises in.
  - **Services**:  a grid of service cards describing your offerings.
  - **Why PCG**:  a short description emphasising your differentiators (accessibility, responsiveness, bilingual expertise, etc.).
  - **Contact**:  simple contact form for visitors to reach out.  At present this form does not send data anywhere; you can integrate it with a Netlify form handler or any backend service of your choice.
  - **Responsive design**:  the layout adapts to mobile, tablet and desktop viewports.

## How to Deploy

1. **Preview locally** (optional):
   - You can open the `index.html` file directly in your browser to preview the site.  If you run a local web server (e.g. `python3 -m http.server` in this directory), you can test relative paths and form behaviour.

2. **Replace your existing Netlify site**:
   - Drag the `pcg-website` folder contents into your Netlify dashboard (or push them to the repository connected to Netlify).  Since this is a static site, Netlify will simply serve the HTML file and assets.
   - If your existing site is built with a framework (e.g. React/Vite), you can still deploy this version by creating a new branch or replacing your build output.  Netlify does not require a build step for this design; it just serves `index.html` and any supporting files.

3. **Add Netlify form handling** (optional):
   - To capture contact form submissions, add the `netlify` attribute to the `<form>` element and include a hidden `name` field.  For example:
     ```html
     <form name="contact" netlify>
       <input type="hidden" name="form-name" value="contact" />
       <!-- your form fields here -->
     </form>
     ```
   - After deploying, Netlify will store submissions in the dashboard and optionally send you email notifications.

4. **Customisation**:
   - Replace the hero background image URL with your own image by editing the `style` attribute in the hero section.  The current image is fetched from an open source Pexels photo to provide visual context.
   - Update the content in the `translations` object to reflect your voice, tone, or additional services.
   - To add more pages, you can duplicate the sections or create additional HTML files and update the navigation accordingly.  For a more complex site, you may consider migrating this design into a React or Vite project.

## Notes

* The year in the footer is set to **2026**, matching the current date of this conversation.  You can update it manually in `index.html` as necessary.
* This is a static prototype without server‑side integration.  If you require dynamic functionality (authentication, dashboards, etc.), you will need to integrate with a backend or full‑featured framework.

If you have any questions or need help customising or extending the site, feel free to ask!